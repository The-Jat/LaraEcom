<div @class(['mb-3 widget-item', 'col-md-' . $columns => $columns]) id="{{ $id }}">
    {!! $content !!}
</div>
