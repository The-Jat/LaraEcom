<?php

// Use to change table heading of each module
if (! defined('BASE_FILTER_TABLE_HEADINGS')) {
    define('BASE_FILTER_TABLE_HEADINGS', 'table_headings');
}

// Use in get list data function in each repository
if (! defined('BASE_FILTER_GET_LIST_DATA')) {
    define('BASE_FILTER_GET_LIST_DATA', 'get_list_data');
}

if (! defined('BASE_FILTER_TABLE_BUTTONS')) {
    define('BASE_FILTER_TABLE_BUTTONS', 'base_filter_table_buttons');
}

if (! defined('BASE_FILTER_TABLE_QUERY')) {
    define('BASE_FILTER_TABLE_QUERY', 'base_filter_table_query');
}
