<span class="dt-length-records">
    <i class="fa fa-globe"></i> <span class="d-none d-sm-inline">{{ trans('core/base::tables.show_from') }}</span> _START_ {{ trans('core/base::tables.to') }} _END_ {{ trans('core/base::tables.in') }} <span class="badge bg-secondary bold badge-dt">_TOTAL_</span> <span class="hidden-xs">{{ trans('core/base::tables.records') }}</span>
</span>
